# My React + Vite Project

### Installation
1. Clone the repository :

```bash
git clone https://github.com/rheinatamara/relationship_website_mobile.git
cd  relationship_website_mobile
```


2. Install dependencies:
```bash
npm install
```
3. Start the development server:
```bash
npm run dev
```
4. Open your browser and navigate to http://localhost:5173/ (default Vite dev server URL).


